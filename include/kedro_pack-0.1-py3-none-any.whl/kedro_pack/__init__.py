"""kedro_proj
"""

__version__ = "0.1"
